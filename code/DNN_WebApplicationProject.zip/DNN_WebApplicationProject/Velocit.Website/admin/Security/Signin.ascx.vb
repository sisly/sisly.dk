'
' DotNetNuke� - http://www.dotnetnuke.com
' Copyright (c) 2002-2005
' by Perpetual Motion Interactive Systems Inc. ( http://www.perpetualmotion.ca )
'
' Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated 
' documentation files (the "Software"), to deal in the Software without restriction, including without limitation 
' the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and 
' to permit persons to whom the Software is furnished to do so, subject to the following conditions:
'
' The above copyright notice and this permission notice shall be included in all copies or substantial portions 
' of the Software.
'
' THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
' TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL 
' THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF 
' CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER 
' DEALINGS IN THE SOFTWARE.
'

Imports System.Web.Security

Imports AspNetSecurity = System.Web.Security

Imports DotNetNuke.Services.Mail

Namespace DotNetNuke.Modules.Admin.Security

	''' -----------------------------------------------------------------------------
	''' <summary>
	''' The Signin PortalModuleBase is used to provide a login for a registered user
	''' portal.
	''' </summary>
    ''' <remarks>
	''' </remarks>
	''' <history>
	''' 	[cnurse]	9/24/2004	Updated to reflect design changes for Help, 508 support
	'''                       and localisation
	''' </history>
	''' -----------------------------------------------------------------------------
	Partial  Class Signin
		Inherits DotNetNuke.Entities.Modules.PortalModuleBase

#Region "Controls"


#End Region

#Region "Private Members"

		Private ipAddress As String

#End Region

#Region "Event Handlers"

		''' -----------------------------------------------------------------------------
		''' <summary>
		''' Page_Load runs when the control is loaded
		''' </summary>
		''' <remarks>
		''' </remarks>
		''' <history>
		''' 	[cnurse]	9/8/2004	Updated to reflect design changes for Help, 508 support
		'''                       and localisation
		''' </history>
		''' -----------------------------------------------------------------------------
		Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

            ' Verify if portal has a customized login page
            If Not Null.IsNull(PortalSettings.LoginTabId) And IsAdminControl() Then
                ' login page exists and trying to access this control directly with url param -> not allowed
                Response.Redirect(NavigateURL(PortalSettings.LoginTabId))
            End If

            DotNetNuke.UI.Utilities.ClientAPI.RegisterKeyCapture(Me.Parent, Me.cmdLogin, Asc(vbCr))

            If Not HttpContext.Current.Request.UserHostAddress Is Nothing Then
                ipAddress = HttpContext.Current.Request.UserHostAddress
            End If

            If PortalSettings.UserRegistration = PortalRegistrationType.NoRegistration Then
                cmdRegister.Visible = False
                TDRegister.Visible = False
                TDLogin.Align = "Center"
            End If

            txtPassword.Attributes.Add("value", txtPassword.Text)

            If Page.IsPostBack = False Then
                Try
                    SetFormFocus(txtUsername)
                Catch
                    'control not there or error setting focus
                End Try
            End If

            lblLogin.Text = Services.Localization.Localization.GetSystemMessage(PortalSettings, "MESSAGE_LOGIN_INSTRUCTIONS")

		End Sub

		''' -----------------------------------------------------------------------------
		''' <summary>
		''' cmdLogin_Click runs when the login button is clicked
		''' </summary>
		''' <remarks>
		''' </remarks>
		''' <history>
		''' 	[cnurse]	9/24/2004	Updated to reflect design changes for Help, 508 support
		'''                       and localisation
		''' </history>
		''' -----------------------------------------------------------------------------
		Private Sub cmdLogin_Click(ByVal sender As Object, ByVal e As EventArgs) Handles cmdLogin.Click

			Dim objUsers As New UserController
			Dim objSecurity As New PortalSecurity
            Dim objMembershipUser As AspNetSecurity.MembershipUser
			Dim strMessage As String
			Dim blnLogin As Boolean = True

            If PortalSettings.UserRegistration = PortalRegistrationType.VerifiedRegistration Then
                Dim objUser As UserInfo = objUsers.GetUserByUsername(PortalSettings.PortalId, txtUsername.Text)
                If Not objUser Is Nothing _
                 AndAlso objUser.Membership.Approved = False _
                 AndAlso objUser.IsSuperUser = False Then
                    blnLogin = False
                    If rowVerification1.Visible Then
                        If txtVerification.Text <> "" Then
                            If txtVerification.Text = (objUser.PortalID.ToString & "-" & objUser.UserID) Then
                                ' set the authorization bit and login time in the userportals table
                                objMembershipUser = AspNetSecurity.Membership.GetUser(objUser.Membership.Username)
                                objMembershipUser.IsApproved = True
                                AspNetSecurity.Membership.UpdateUser(objMembershipUser)
                                blnLogin = True
                            Else
                                strMessage = Services.Localization.Localization.GetString("InvalidCode", Me.LocalResourceFile)
                                UI.Skins.Skin.AddModuleMessage(Me, strMessage, UI.Skins.Controls.ModuleMessage.ModuleMessageType.RedError)
                            End If
                        Else
                            strMessage = Services.Localization.Localization.GetString("EnterCode", Me.LocalResourceFile)
                            UI.Skins.Skin.AddModuleMessage(Me, strMessage, UI.Skins.Controls.ModuleMessage.ModuleMessageType.GreenSuccess)
                        End If
                    Else
                        rowVerification1.Visible = True
                        rowVerification2.Visible = True
                    End If
                End If
            End If

            If blnLogin Then
                If objSecurity.UserLogin(txtUsername.Text, txtPassword.Text, PortalId, PortalSettings.PortalName, ipAddress, chkCookie.Checked) <> -1 Then

                    ' Store preferredlocale in cookie
                    Dim objUserInfo As UserInfo = objUsers.GetUserByUsername(PortalSettings.PortalId, txtUsername.Text)
                    CType(Page, PageBase).SetLanguage(objUserInfo.Profile.PreferredLocale)

                    ' redirect browser - override is used if the user defined login tab has no signin control
                    If PortalSettings.HomeTabId <> -1 And Request.QueryString("override") Is Nothing Then
                        ' user defined tab
                        Response.Redirect(NavigateURL(PortalSettings.HomeTabId), True)
                    Else
                        ' admin tab
                        Response.Redirect(NavigateURL(), True)
                    End If
                Else
                    Dim objUserInfo As UserInfo = objUsers.GetUserByUsername(PortalSettings.PortalId, txtUsername.Text)
                    If Not objUserInfo Is Nothing AndAlso objUserInfo.Membership.LockedOut Then
                        strMessage = Services.Localization.Localization.GetString("UserLockedOut", Me.LocalResourceFile)
                    Else
                        Dim objAuthentication As New DotNetNuke.Security.Authentication.AuthenticationController
                        Dim objAuthUser As DotNetNuke.Security.Authentication.UserInfo = objAuthentication.ProcessFormAuthentication(txtUsername.Text, txtPassword.Text)
                        Dim _userID As Integer = -1

                        If Not objAuthUser Is Nothing AndAlso objUserInfo Is Nothing Then
                            ' Add this user into DNN database for better performance on next logon
                            Dim objAuthUsers As New DotNetNuke.Security.Authentication.UserController
                            _userID = objAuthUsers.AddDNNUser(objAuthUser)

                            Dim UserRegistrationStatus As AspNetSecurity.MembershipCreateStatus
                            UserRegistrationStatus = CType(_userID * -1, AspNetSecurity.MembershipCreateStatus)

                            ' Windows/DNN password validation should be same, check this status here
                            strMessage = objUsers.GetRegistrationStatus(UserRegistrationStatus)
                            If UserRegistrationStatus = AspNetSecurity.MembershipCreateStatus.InvalidPassword Then
                                Dim strInvalidPassword As String = Services.Localization.Localization.GetString("InvalidPassword", Me.LocalResourceFile)
                                strInvalidPassword = strInvalidPassword.Replace("[PasswordLength]", AspNetSecurity.Membership.MinRequiredPasswordLength.ToString)
                                strInvalidPassword = strInvalidPassword.Replace("[NoneAlphabet]", AspNetSecurity.Membership.MinRequiredNonAlphanumericCharacters.ToString)
                                strMessage += "<br>" & strInvalidPassword
                            End If

                        ElseIf (Not objAuthUser Is Nothing) AndAlso (Not objUserInfo Is Nothing) Then
                            ' User might has been imported by Admin or automatically added with random password
                            ' update DNN password to match with authenticated password from AD                            
                            If objUserInfo.Membership.Password <> txtPassword.Text Then
                                objUsers.SetPassword(objUserInfo, objUserInfo.Membership.Password, txtPassword.Text)
                            End If
                            _userID = objUserInfo.UserID

                        Else
                            strMessage = Services.Localization.Localization.GetString("LoginFailed", Me.LocalResourceFile)
                        End If

                        If (_userID > 0) Then
                            ' Authenticated with DNN
                            If objSecurity.UserLogin(txtUsername.Text, txtPassword.Text, PortalId, PortalSettings.PortalName, ipAddress, chkCookie.Checked) <> -1 Then
                                ' redirect browser - always redirect to home tab                    
                                Response.Redirect(NavigateURL(PortalSettings.HomeTabId), True)
                            Else
                                strMessage = Services.Localization.Localization.GetString("LoginFailed", Me.LocalResourceFile)
                            End If
                        Else
                            UI.Skins.Skin.AddModuleMessage(Me, strMessage, UI.Skins.Controls.ModuleMessage.ModuleMessageType.RedError)
                        End If
                    End If
                End If
            End If

		End Sub

		''' -----------------------------------------------------------------------------
		''' <summary>
		''' cmdSendPassword_Click runs when the Password Reminder button is clicked
		''' </summary>
		''' <remarks>
		''' </remarks>
		''' <history>
		''' 	[cnurse]	9/24/2004	Updated to reflect design changes for Help, 508 support
		'''                       and localisation
		''' </history>
		''' -----------------------------------------------------------------------------
		Private Sub cmdSendPassword_Click(ByVal sender As System.Object, ByVal e As EventArgs) Handles cmdSendPassword.Click

			Dim strMessage As String

			If Trim(txtUsername.Text) <> "" Then
				Dim objUsers As New UserController
				Dim objSecurity As New PortalSecurity

				Dim objUser As UserInfo = objUsers.GetUserByUsername(PortalSettings.PortalId, txtUsername.Text)

				If Not objUser Is Nothing Then
                    If objUser.IsSuperUser Then
                        objUser.Membership.Password = "******"
                    End If
                    Mail.SendMail(PortalSettings.Email, objUser.Membership.Email, "", _
                        Services.Localization.Localization.GetSystemMessage(objUser.Profile.PreferredLocale, PortalSettings, "EMAIL_PASSWORD_REMINDER_SUBJECT", objUser), _
                        Services.Localization.Localization.GetSystemMessage(objUser.Profile.PreferredLocale, PortalSettings, "EMAIL_PASSWORD_REMINDER_BODY", objUser), _
                        "", "", "", "", "", "")
                    strMessage = Services.Localization.Localization.GetString("PasswordSent", Me.LocalResourceFile)
                    UI.Skins.Skin.AddModuleMessage(Me, strMessage, UI.Skins.Controls.ModuleMessage.ModuleMessageType.GreenSuccess)
                    Dim objEventLog As New Services.Log.EventLog.EventLogController
                    Dim objEventLogInfo As New Services.Log.EventLog.LogInfo
                    objEventLogInfo.AddProperty("IP", ipAddress)
                    objEventLogInfo.LogPortalID = PortalSettings.PortalId
                    objEventLogInfo.LogPortalName = PortalSettings.PortalName
                    objEventLogInfo.LogUserID = UserId
                    objEventLogInfo.LogUserName = objSecurity.InputFilter(txtUsername.Text, PortalSecurity.FilterFlag.NoScripting Or PortalSecurity.FilterFlag.NoMarkup)
                    objEventLogInfo.LogTypeKey = "PASSWORD_SENT_SUCCESS"
                    objEventLog.AddLog(objEventLogInfo)
                Else
                    Dim objEventLog As New Services.Log.EventLog.EventLogController
                    Dim objEventLogInfo As New Services.Log.EventLog.LogInfo
                    objEventLogInfo.AddProperty("IP", ipAddress)
                    objEventLogInfo.LogPortalID = PortalSettings.PortalId
                    objEventLogInfo.LogPortalName = PortalSettings.PortalName
                    objEventLogInfo.LogUserID = UserId
                    objEventLogInfo.LogUserName = objSecurity.InputFilter(txtUsername.Text, PortalSecurity.FilterFlag.NoScripting Or PortalSecurity.FilterFlag.NoMarkup)
                    objEventLogInfo.LogTypeKey = "PASSWORD_SENT_FAILURE"
                    objEventLog.AddLog(objEventLogInfo)
                    strMessage = Services.Localization.Localization.GetString("UsernameError", Me.LocalResourceFile)
                    UI.Skins.Skin.AddModuleMessage(Me, strMessage, UI.Skins.Controls.ModuleMessage.ModuleMessageType.RedError)
                End If

            Else
                strMessage = Services.Localization.Localization.GetString("EnterUsername", Me.LocalResourceFile)
                UI.Skins.Skin.AddModuleMessage(Me, strMessage, UI.Skins.Controls.ModuleMessage.ModuleMessageType.RedError)
            End If

		End Sub

		''' -----------------------------------------------------------------------------
		''' <summary>
		''' cmdRegister_Click runs when the register button is clicked
		''' </summary>
		''' <remarks>
		''' </remarks>
		''' <history>
		''' 	[cnurse]	9/24/2004	Updated to reflect design changes for Help, 508 support
		'''                       and localisation
		''' </history>
		''' -----------------------------------------------------------------------------
		Private Sub cmdRegister_Click(ByVal sender As Object, ByVal e As EventArgs) Handles cmdRegister.Click
			If PortalSettings.UserTabId <> -1 Then
				' user defined tab
				Response.Redirect(NavigateURL(PortalSettings.UserTabId), True)
			Else
				' admin tab
				Response.Redirect(NavigateURL("Register"), True)
			End If
		End Sub

#End Region

#Region " Web Form Designer Generated Code "

		'This call is required by the Web Form Designer.
		<System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

        End Sub

		Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
			'CODEGEN: This method call is required by the Web Form Designer
			'Do not modify it using the code editor.
			InitializeComponent()
		End Sub

#End Region

	End Class

End Namespace
