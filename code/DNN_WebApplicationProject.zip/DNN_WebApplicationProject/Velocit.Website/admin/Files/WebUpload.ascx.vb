'
' DotNetNuke� - http://www.dotnetnuke.com
' Copyright (c) 2002-2005
' by Perpetual Motion Interactive Systems Inc. ( http://www.perpetualmotion.ca )
'
' Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated 
' documentation files (the "Software"), to deal in the Software without restriction, including without limitation 
' the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and 
' to permit persons to whom the Software is furnished to do so, subject to the following conditions:
'
' The above copyright notice and this permission notice shall be included in all copies or substantial portions 
' of the Software.
'
' THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
' TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL 
' THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF 
' CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER 
' DEALINGS IN THE SOFTWARE.
'

Imports DotNetNuke.Services.FileSystem
Imports ICSharpCode.SharpZipLib.Zip
Imports System.IO
Imports DotNetNuke.Entities.Modules

Namespace DotNetNuke.Modules.Admin.FileSystem

    ''' -----------------------------------------------------------------------------
	''' Project	 : DotNetNuke
	''' Class	 : WebUpload
    ''' -----------------------------------------------------------------------------
	''' <summary>
	''' Supplies the functionality for uploading files to the Portal
	''' </summary>
	''' <remarks>
	''' </remarks>
	''' <history>
	'''   [cnurse] 16/9/2004  Updated for localization, Help and 508
	''' </history>
	''' -----------------------------------------------------------------------------
	Partial  Class WebUpload
		Inherits DotNetNuke.Entities.Modules.PortalModuleBase

#Region "Controls"


		'Upload
		'Protected WithEvents optFileType As System.Web.UI.WebControls.RadioButtonList

		'Message

		'Upload Log

#End Region

#Region "Members"

        Public Shared arrTypes As ArrayList = New ArrayList
		Private _FileType As UploadType		   ' content files
		Private _FileTypeName As String
		Private _DestinationFolder As String		   ' content files
		Private _UploadRoles As String
		Private _RootFolder As String

#End Region

#Region "Public Properties"
		Public ReadOnly Property DestinationFolder() As String
			Get
				If _DestinationFolder Is Nothing Then
					_DestinationFolder = String.Empty
					If Not (Request.QueryString("dest") Is Nothing) Then
						_DestinationFolder = QueryStringDecode(Request.QueryString("dest"))
					End If
				End If
                Return _DestinationFolder.Replace("\", "/")
			End Get
		End Property

		Public ReadOnly Property FileType() As UploadType
			Get
				_FileType = UploadType.File
				If Not (Request.QueryString("ftype") Is Nothing) Then
					'The select statement ensures that the parameter can be converted to UploadType
					Select Case Request.QueryString("ftype").ToLower
						Case "file", "container", "skin", "module", "languagepack"
							_FileType = DirectCast(System.Enum.Parse(GetType(UploadType), Request.QueryString("ftype")), UploadType)
					End Select
				End If
				Return _FileType
			End Get
		End Property

		Public ReadOnly Property FileTypeName() As String
			Get
				If FileTypeName Is Nothing Then
					_FileTypeName = Services.Localization.Localization.GetString(FileType.ToString, Me.LocalResourceFile)
				End If
				Return _FileTypeName
			End Get
		End Property

		Public ReadOnly Property UploadRoles() As String
			Get
				If _UploadRoles Is Nothing Then
					_UploadRoles = String.Empty

					Dim objModules As New ModuleController
					'TODO:  Should replace this with a finder method in PortalSettings to look in the cached modules of the activetab - jmb 11/25/2004
					Dim ModInfo As ModuleInfo

					If Me.PortalSettings.ActiveTab.ParentId = Me.PortalSettings.SuperTabId Then
						ModInfo = objModules.GetModuleByDefinition(Null.NullInteger, "File Manager")
					Else
						ModInfo = objModules.GetModuleByDefinition(PortalId, "File Manager")
					End If

					Dim settings As Hashtable = PortalSettings.GetModuleSettings(ModInfo.ModuleID)
					If Not CType(settings("uploadroles"), String) Is Nothing Then
						_UploadRoles = CType(settings("uploadroles"), String)
					End If
				End If

				Return _UploadRoles
			End Get
		End Property

		Public ReadOnly Property RootFolder() As String
			Get
				If _RootFolder Is Nothing Then
					If PortalSettings.ActiveTab.ParentId = PortalSettings.SuperTabId Then
						_RootFolder = Request.MapPath(Common.Globals.HostPath)
					Else
						_RootFolder = Request.MapPath(PortalSettings.HomeDirectory)
					End If
				End If

				Return _RootFolder
			End Get
		End Property
#End Region

#Region "Private Methods"

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' This routine populates the Folder List Drop Down
        '''There is no reference to permissions here as all folders should be available to the admin.
        ''' </summary>
        ''' <param name="ChildDir"></param>
        ''' <remarks>
        ''' </remarks>
        ''' <history>
        '''   [Philip Beadle] 5/10/2004  Added
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Private Sub LoadFolders(ByVal ChildDir As DirectoryInfo)
            Dim CurrentDir As DirectoryInfo
            Dim ChildDirs As DirectoryInfo()
            Dim ChildDirirectory As DirectoryInfo
            Dim ParentFolderName As String = ChildDir.FullName.Substring(lblRootFolder.Text.Length)

            CurrentDir = ChildDir
            ChildDirs = CurrentDir.GetDirectories
            For Each ChildDirirectory In ChildDirs
                Dim FolderItem As New ListItem
                Dim ItemText As String = ParentFolderName & "/" & ChildDirirectory.Name
                If ItemText.StartsWith("/") Then
                    ItemText = ItemText.Remove(0, 1)
                End If
                Dim ItemValue As String = ItemText & "/"
                FolderItem.Text = ItemText.Replace("\", "/")
                FolderItem.Value = ItemValue.Replace("\", "/")
                ddlFolders.Items.Add(FolderItem)
                If ChildDirirectory.GetDirectories.Length > 0 Then
                    LoadFolders(ChildDirirectory)
                End If
            Next
        End Sub

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' This routine checks the Access Security
        ''' </summary>
        ''' <remarks>
        ''' </remarks>
        ''' <history>
        '''   [cnurse] 1/21/2005  Documented
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Private Sub CheckSecurity()
            Dim DenyAccess As Boolean = False
            If PortalSecurity.IsInRole(PortalSettings.AdministratorRoleName.ToString) = False And PortalSecurity.IsInRoles(UploadRoles) = False Then
                DenyAccess = True
            Else
                If Me.PortalSettings.ActiveTab.ParentId = Me.PortalSettings.AdminTabId Then
                    Select Case FileType
                        Case UploadType.LanguagePack, UploadType.Module
                            DenyAccess = True
                        Case UploadType.Skin, UploadType.Container
                            If (Convert.ToString(PortalSettings.HostSettings("SkinUpload")) = "G") And (UserInfo.IsSuperUser = False) Then
                                DenyAccess = True
                            End If
                    End Select
                End If

                If Me.PortalSettings.ActiveTab.ParentId = Me.PortalSettings.SuperTabId Then
                    If Not UserInfo.IsSuperUser Then
                        DenyAccess = True
                    End If
                End If
            End If

            If DenyAccess Then
                Response.Redirect(NavigateURL("Access Denied"), True)
            End If

        End Sub

        Private Function GetFiles() As ArrayList

            Dim arrFiles As ArrayList = CType(DataCache.GetCache("Files" & UserId.ToString), ArrayList)
            If arrFiles Is Nothing Then
                arrFiles = New ArrayList
            End If

            Return arrFiles

        End Function

        Private Sub SaveFiles(ByVal arrFiles As ArrayList)

            DataCache.SetCache("Files" & UserId.ToString, arrFiles)

        End Sub
#End Region

#Region "Public Methods"

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' This routine determines the Return Url
        ''' </summary>
        ''' <remarks>
        ''' </remarks>
        ''' <history>
        '''   [cnurse] 1/21/2005  Documented
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Public Function ReturnURL() As String
            Dim TabID As Integer = PortalSettings.HomeTabId

            If Not Request.Params("rtab") Is Nothing Then
                TabID = Integer.Parse(Request.Params("rtab"))
            End If
            Return NavigateURL(TabID)
        End Function

#End Region

#Region "Event Handlers"

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' The Page_Load runs when the page loads
        ''' </summary>
        ''' <param name="sender"></param>
        ''' <param name="e"></param>
        ''' <remarks>
        ''' </remarks>
        ''' <history>
        '''   [cnurse] 16/9/2004  Updated for localization, Help and 508
        '''   [VMasanas]  9/28/2004   Changed redirect to Access Denied
        '''   [Philip Beadle]  5/10/2004  Added folder population section.
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
            Try
                CheckSecurity()

                'Get localized Strings
                Dim strHost As String = Services.Localization.Localization.GetString("HostRoot", Me.LocalResourceFile)
                Dim strPortal As String = Services.Localization.Localization.GetString("PortalRoot", Me.LocalResourceFile)

                If Not Page.IsPostBack Then
                    DataCache.SetCache("Files" & UserId.ToString, New ArrayList)
                    arrTypes.Clear()

                    lblUploadType.Text = Services.Localization.Localization.GetString("UploadType" & FileType.ToString, Me.LocalResourceFile)
                    If FileType = UploadType.File Then
                        trFolders.Visible = True
                        trRoot.Visible = True
                        trUnzip.Visible = True

                        If PortalSettings.ActiveTab.ParentId = PortalSettings.SuperTabId Then
                            lblRootType.Text = strHost & ":"
                            lblRootFolder.Text = RootFolder
                        Else
                            lblRootType.Text = strPortal & ":"
                            lblRootFolder.Text = RootFolder
                        End If
                        ddlFolders.Items.Clear()
                        Dim FolderItem As New ListItem
                        FolderItem.Text = "Root"
                        FolderItem.Value = String.Empty
                        ddlFolders.Items.Add(FolderItem)
                        Dim Root As New DirectoryInfo(lblRootFolder.Text)
                        LoadFolders(Root)
                        If DestinationFolder.Length > 0 Then
                            If Not ddlFolders.Items.FindByText(DestinationFolder) Is Nothing Then
                                ddlFolders.Items.FindByText(DestinationFolder).Selected = True
                            End If
                        End If
                    End If

                    chkUnzip.Checked = False

                End If

            Catch exc As Exception    'Module failed to load
                ProcessModuleLoadException(Me, exc)
            End Try
        End Sub

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' The cmdAdd_Click runs when the Add Button is clicked
        ''' </summary>
        ''' <param name="sender"></param>
        ''' <param name="e"></param>
        ''' <remarks>
        ''' </remarks>
        ''' <history>
        '''   [cnurse] 16/9/2004  Updated for localization, Help and 508
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Private Sub cmdAdd_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdAdd.Click

            Try
                If Page.IsPostBack Then
                    If cmdBrowse.PostedFile.FileName <> "" Then
                        'Get Files from Cache
                        Dim arrFiles As ArrayList = GetFiles()

                        'Add File
                        arrFiles.Add(cmdBrowse)
                        arrTypes.Add(FileType)
                        lstFiles.Items.Add(FileTypeName & " - " & cmdBrowse.PostedFile.FileName)

                        'Save Files to Cache
                        SaveFiles(arrFiles)
                    End If
                End If

            Catch exc As Exception    'Module failed to load
                ProcessModuleLoadException(Me, exc)
            End Try
        End Sub

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' The cmdCancel_Click runs when the Cancel Button is clicked
        ''' </summary>
        ''' <param name="sender"></param>
        ''' <param name="e"></param>
        ''' <remarks>
        ''' </remarks>
        ''' <history>
        '''   [cnurse] 16/9/2004  Updated for localization, Help and 508
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Private Sub cmdCancel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdCancel.Click
            Response.Redirect(ReturnURL(), True)
        End Sub

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' The cmdRemove_Click runs when the Remove Button is clicked
        ''' </summary>
        ''' <param name="sender"></param>
        ''' <param name="e"></param>
        ''' <remarks>
        ''' </remarks>
        ''' <history>
        '''   [cnurse] 16/9/2004  Updated for localization, Help and 508
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Private Sub cmdRemove_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdRemove.Click
            Try
                If Not lstFiles.SelectedItem Is Nothing Then
                    'Get Files from Cache
                    Dim arrFiles As ArrayList = GetFiles()

                    'Remove File
                    arrFiles.RemoveAt(lstFiles.SelectedIndex)
                    arrTypes.RemoveAt(lstFiles.SelectedIndex)
                    lstFiles.Items.Remove(lstFiles.SelectedItem.Text)

                    'Save Files to Cache
                    SaveFiles(arrFiles)
                End If

            Catch exc As Exception    'Module failed to load
                ProcessModuleLoadException(Me, exc)
            End Try
        End Sub

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' The cmdReturn_Click runs when the Return Button is clicked
        ''' </summary>
        ''' <param name="sender"></param>
        ''' <param name="e"></param>
        ''' <remarks>
        ''' </remarks>
        ''' <history>
        '''   [cnurse] 16/9/2004  Updated for localization, Help and 508
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Private Sub cmdReturn_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdReturn1.Click, cmdReturn2.Click
            Response.Redirect(ReturnURL(), True)
        End Sub

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' The cmdUpload_Click runs when the Upload Button is clicked
        ''' </summary>
        ''' <param name="sender"></param>
        ''' <param name="e"></param>
        ''' <remarks>
        ''' </remarks>
        ''' <history>
        '''   [cnurse] 16/9/2004  Updated for localization, Help and 508
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Private Sub cmdUpload_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdUpload.Click
            Try
                Dim strFileName As String
                Dim strExtension As String = ""
                Dim strMessage As String = ""

                Dim objHtmlInputFile As System.Web.UI.HtmlControls.HtmlInputFile
                Dim intItem As Integer

                'Get localized Strings
                Dim strInvalid As String = Services.Localization.Localization.GetString("InvalidExt", Me.LocalResourceFile)

                'Get Files from Cache
                Dim arrFiles As ArrayList = GetFiles()

                For intItem = 0 To arrFiles.Count - 1
                    objHtmlInputFile = CType(arrFiles(intItem), HtmlInputFile)

                    strFileName = System.IO.Path.GetFileName(objHtmlInputFile.PostedFile.FileName)
                    strExtension = Path.GetExtension(strFileName)

                    Select Case CType(arrTypes(intItem), UploadType)
                        Case UploadType.File        ' content files
                            strMessage += UploadFile(RootFolder & ddlFolders.SelectedItem.Value.Replace("/", "\"), objHtmlInputFile.PostedFile, chkUnzip.Checked)
                        Case UploadType.Skin        ' skin package
                            If strExtension.ToLower = ".zip" Then
                                Dim objSkins As New UI.Skins.SkinController
                                Dim objSkin As UI.Skins.SkinInfo
                                Dim objLbl As New Label
                                objLbl.CssClass = "Normal"
                                objLbl.Text = objSkins.UploadSkin(RootFolder, objSkin.RootSkin, Path.GetFileNameWithoutExtension(objHtmlInputFile.PostedFile.FileName), objHtmlInputFile.PostedFile.InputStream)
                                phPaLogs.Controls.Add(objLbl)
                            Else
                                strMessage += strInvalid & " " & FileTypeName & " " & strFileName
                            End If
                        Case UploadType.Container        ' container package
                            If strExtension.ToLower = ".zip" Then
                                Dim objSkins As New UI.Skins.SkinController
                                Dim objSkin As UI.Skins.SkinInfo
                                Dim objLbl As New Label
                                objLbl.CssClass = "Normal"
                                objLbl.Text = objSkins.UploadSkin(RootFolder, objSkin.RootContainer, Path.GetFileNameWithoutExtension(objHtmlInputFile.PostedFile.FileName), objHtmlInputFile.PostedFile.InputStream)
                                phPaLogs.Controls.Add(objLbl)
                            Else
                                strMessage += strInvalid & " " & FileTypeName & " " & strFileName
                            End If
                        Case UploadType.Module        ' custom module
                            If strExtension.ToLower = ".zip" Then
                                phPaLogs.Visible = True
                                Dim pa As New DotNetNuke.Modules.Admin.ResourceInstaller.PaInstaller(CType(objHtmlInputFile.PostedFile.InputStream, Stream), Request.MapPath("."))

                                pa.Install()

                                phPaLogs.Controls.Add(pa.InstallerInfo.Log.GetLogsTable)
                            Else
                                strMessage += strInvalid & " " & FileTypeName & " " & strFileName
                            End If
                        Case UploadType.LanguagePack
                            If strExtension.ToLower = ".zip" Then
                                Dim objLangPack As New DotNetNuke.Services.Localization.LocaleFilePackReader

                                phPaLogs.Controls.Add(objLangPack.Install(objHtmlInputFile.PostedFile.InputStream).GetLogsTable)
                            Else
                                strMessage += strInvalid & " " & FileTypeName & " " & strFileName
                            End If

                    End Select
                Next

                'Clear Cache
                DataCache.RemoveCache("Files" & UserId.ToString)

                If phPaLogs.Controls.Count > 0 Then
                    tblUpload.Visible = False
                    tblLogs.Visible = True
                ElseIf strMessage = "" Then
                    Response.Redirect(ReturnURL(), True)
                Else
                    lblMessage.Text = strMessage
                End If

            Catch exc As Exception    'Module failed to load
                ProcessModuleLoadException(Me, exc)
            End Try
        End Sub

#End Region

#Region " Web Form Designer Generated Code "

        'This call is required by the Web Form Designer.
        <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

        End Sub

        Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
            'CODEGEN: This method call is required by the Web Form Designer
            'Do not modify it using the code editor.
            InitializeComponent()
        End Sub

#End Region

    End Class

End Namespace
