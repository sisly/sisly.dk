using System;
using System.Collections;
using System.IO;
using System.Threading;
using System.Web;
using DotNetNuke.Common;
using DotNetNuke.Common.Utilities;
using DotNetNuke.Entities.Portals;
using DotNetNuke.Services.Exceptions;
using DotNetNuke.Services.Log.EventLog;
using DotNetNuke.Services.Scheduling;

namespace DotNetNuke.Common
{
    public class Global : System.Web.HttpApplication
    {
        private void CheckVersion()
        {
            if(Request.Url.LocalPath.ToLower().EndsWith(".html"))
            {
                return;
            }
            bool autoUpgrade;
            if (Config.GetSetting("AutoUpgrade") == null)
            {
                autoUpgrade = true;
            }
            else
            {
                autoUpgrade = bool.Parse(Config.GetSetting("AutoUpgrade"));
            }
            if (Globals.GetUpgradeStatus() == Globals.UpgradeStatus.Install || Globals.GetUpgradeStatus() == Globals.UpgradeStatus.Upgrade)
            {
                if (autoUpgrade)
                {
                    Response.Redirect("~/Install/Install.aspx?mode=Install");
                }
                else
                {
                    CreateUnderConstructionPage();
                    Response.Redirect("~/Install/UnderConstruction.htm");
                }
            }
            else if (Globals.GetUpgradeStatus() == Globals.UpgradeStatus.Error)
            {
                if (autoUpgrade)
                {
                    Response.Redirect("~/Install/Install.aspx?mode=none");
                }
                else
                {
                    CreateUnderConstructionPage();
                    Response.Redirect("~/Install/UnderConstruction.htm");
                }
            }
        }

        private void CreateUnderConstructionPage()
        {
            if (!(File.Exists(System.Web.HttpContext.Current.Server.MapPath("~/Install/UnderConstruction.htm"))))
            {
                if (File.Exists(System.Web.HttpContext.Current.Server.MapPath("~/Install/UnderConstruction.template.htm")))
                {
                    File.Copy(System.Web.HttpContext.Current.Server.MapPath("~/Install/UnderConstruction.template.htm"), System.Web.HttpContext.Current.Server.MapPath("~/Install/UnderConstruction.htm"));
                }
            }
        }

        private void LogEnd()
        {
            try
            {
                EventLogController objEv = new EventLogController();
                LogInfo objEventLogInfo = new LogInfo();
                objEventLogInfo.BypassBuffering = true;
                objEventLogInfo.LogTypeKey = Services.Log.EventLog.EventLogController.EventLogType.APPLICATION_SHUTTING_DOWN.ToString();
                objEv.AddLog(objEventLogInfo);
            }
            catch (Exception exc)
            {
               Exceptions.LogException(exc);
            }
            LoggingProvider.Instance().PurgeLogBuffer();
        }

        private void CacheMappedDirectory()
        {
            Services.FileSystem.FolderController objFolderController = new Services.FileSystem.FolderController();
            PortalController objPortalController = new PortalController();
            ArrayList arrPortals = objPortalController.GetPortals();
            for (int i = 0; i <= arrPortals.Count - 1; i++)
            {
                PortalInfo objPortalInfo = ((PortalInfo)(arrPortals[i]));
                objFolderController.SetMappedDirectory(objPortalInfo, HttpContext.Current);
            }
        }

        private void StopScheduler()
        {
            SchedulingProvider.Instance().Halt("Stopped by Application_End");
        }

        public static void LogStart()
        {
            EventLogController objEv = new EventLogController();
            LogInfo objEventLogInfo = new LogInfo();
            objEventLogInfo.BypassBuffering = true;
            objEventLogInfo.LogTypeKey = Services.Log.EventLog.EventLogController.EventLogType.APPLICATION_START.ToString();
            objEv.AddLog(objEventLogInfo);
        }

        public static void StartScheduler()
        {
            if (SchedulingProvider.SchedulerMode == SchedulerMode.TIMER_METHOD)
            {
                SchedulingProvider scheduler = SchedulingProvider.Instance();
                scheduler.RunEventSchedule(EventName.APPLICATION_START);
                Thread newThread = new Thread(new ThreadStart(scheduler.Start));
                newThread.IsBackground = true;
                newThread.Start();
            }
        }

        protected void Application_Start(object Sender, EventArgs E)
        {
            CheckVersion();
            CacheMappedDirectory();
            LogStart();
            StartScheduler();
        }

        protected void Application_End(object Sender, EventArgs E)
        {
            LogEnd();
            StopScheduler();
        }

        protected void Application_BeginRequest(object sender, EventArgs e)
        {
            if (Request.Url.LocalPath.EndsWith("Install.aspx"))
            {
                return;
            }
            string installationDate = Config.GetSetting("InstallationDate");
            if (installationDate == null | installationDate == "")
            {
                Response.Redirect("~/Install/Install.aspx?mode=none");
            }
            try
            {
                if (Services.Scheduling.SchedulingProvider.SchedulerMode == SchedulerMode.REQUEST_METHOD && Services.Scheduling.SchedulingProvider.ReadyForPoll)
                {
                    SchedulingProvider scheduler = SchedulingProvider.Instance();
                    Thread RequestScheduleThread = new Thread(new ThreadStart(scheduler.ExecuteTasks));
                    RequestScheduleThread.IsBackground = true;
                    RequestScheduleThread.Start();
                    Services.Scheduling.SchedulingProvider.ScheduleLastPolled = DateTime.Now;
                }
            }
            catch (Exception exc)
            {
                Exceptions.LogException(exc);
            }
        }
    }
}