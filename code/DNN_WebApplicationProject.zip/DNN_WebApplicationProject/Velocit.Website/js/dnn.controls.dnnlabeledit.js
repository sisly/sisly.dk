if (typeof(dnn_control) == 'undefined')
	eval('function dnn_control() {}')

dnn_control.prototype.initLabelEdit = function (oCtl) 
{
	dnn.controls.controls[oCtl.id] = new dnn.controls.DNNLabelEdit(oCtl);
	return dnn.controls.controls[oCtl.id];
}

//------- Constructor -------//
dnn_control.prototype.DNNLabelEdit = function (o)
{
	this.ns = o.id;               //stores namespace for menu
	this.control = o;                    //stores control
	this.editWrapper = null;	//stores dnn wrapper for abstracted edit control
	this.editContainer = null; //stores container of the control (necessary for iframe controls)
	this.editControl = null; //stores reference to underlying edit control (input, span, textarea)
	this.prevText = '';	

	this.css = o.className;	
	this.cssEdit = __dl_getAttr(o, 'cssEdit', '');
	this.cssWork = __dl_getAttr(o, 'cssWork', '');
	this.cssOver = __dl_getAttr(o, 'cssOver', '');
	this.sysImgPath = __dl_getAttr(o, 'sysimgpath', '');
	this.callBack = __dl_getAttr(o, 'callback', '');
	this.callBackStatFunc = __dl_getAttr(o, 'callbackSF', '');
	this.eventName = __dl_getAttr(o, 'eventName', 'onclick');
	this.editEnabled = __dl_getAttr(o, 'editEnabled', '1') == '1';
	this.multiLineEnabled = __dl_getAttr(o, 'multiline', '0') == '1';
	this.richTextEnabled = __dl_getAttr(o, 'richtext', '0') == '1';
	this.supportsCE = (document.body.contentEditable != null);		
		
	dnn.dom.addSafeHandler(o, this.eventName, this, 'performEdit');
	dnn.dom.addSafeHandler(o, 'onmouseover', this, 'mouseOver');
	dnn.dom.addSafeHandler(o, 'onmouseout', this, 'mouseOut');
	
}

//--- Event Handlers ---//
dnn_control.prototype.DNNLabelEdit.prototype.performEdit = function () 
{
	this.initEditWrapper();
	this.editContainer.style.height = dnn.dom.positioning.elementHeight(this.control) + 4;
	this.editContainer.style.width = dnn.dom.positioning.elementWidth(this.control.parentNode) //'100%';
	this.editContainer.style.display = '';
	//this.editContainer.style.visibility = '';	//firefox workaround... can't do display none
	this.editContainer.style.overflow = 'auto';
	this.editContainer.style.overflowX = 'hidden';

	
	this.prevText = this.control.innerHTML;
	this.editWrapper.setText(this.prevText);
	this.initEditControl();
	this.control.style.display = 'none';
}

dnn_control.prototype.DNNLabelEdit.prototype.mouseOver = function () 
{
	this.control.className = this.css + ' ' + this.cssOver;
}

dnn_control.prototype.DNNLabelEdit.prototype.mouseOut = function () 
{
	this.control.className = this.css;
}

dnn_control.prototype.DNNLabelEdit.prototype.initEditWrapper = function()
{
	if (this.editWrapper == null)
	{
		var oTxt;
		if (this.richTextEnabled && this.supportsCE)	//disabling firefox for now
		{
			var func = dnn.dom.getObjMethRef(this, 'initEditControl');
			oTxt = new dnn.controls.DNNRichText(func);
		}
		else
			oTxt = new dnn.controls.DNNInputText(this.multiLineEnabled);
				
		this.editWrapper = oTxt;
		this.editContainer = this.editWrapper.container;
		this.control.parentNode.appendChild(this.editContainer);
		if (this.richTextEnabled && this.supportsCE)	//control is instantly available (not an iframe)
			this.initEditControl();
	}
}

dnn_control.prototype.DNNLabelEdit.prototype.initEditControl = function () 
{
	if (this.editWrapper.initialized)
	{
		this.editControl = this.editWrapper.control;
		this.editControl.className = this.control.className + ' ' + this.cssEdit;
		this.editWrapper.focus();
		if (this.editWrapper.supportsCE || this.editWrapper.isRichText == false)
		{
			dnn.dom.addSafeHandler(this.editContainer, 'onblur', this, 'persistEdit');	
			dnn.dom.addSafeHandler(this.editControl, 'onkeypress', this, 'handleKeyPress');	
		}
		else
		{
			dnn.dom.attachEvent(this.editContainer.contentWindow.document, 'onblur', dnn.dom.getObjMethRef(this, 'persistEdit'));	
			dnn.dom.attachEvent(this.editContainer.contentWindow.document, 'onkeypress', dnn.dom.getObjMethRef(this, 'handleKeyPress'));			
		}
	}
}

dnn_control.prototype.DNNLabelEdit.prototype.persistEdit = function () 
{
	if (this.editWrapper.getText() != this.prevText)
	{
		this.editControl.className = this.control.className + ' ' + this.cssWork;
		eval(this.callBack.replace('[TEXT]', dnn.escapeForEval(this.editWrapper.getText())));
	}
	else
		this.showLabel();
}

dnn_control.prototype.DNNLabelEdit.prototype.cancelEdit = function () 
{
	this.editWrapper.setText(this.prevText);
	this.showLabel();
}

dnn_control.prototype.DNNLabelEdit.prototype.callBackStatus = function (result, ctx) 
{
	var oLbl = ctx;
	if (oLbl.callBackStatFunc != null && oLbl.callBackStatFunc.length > 0)
	{
		var oPointerFunc = eval(oLbl.callBackStatFunc);
		oPointerFunc(result, ctx);	
	}	
}

dnn_control.prototype.DNNLabelEdit.prototype.callBackSuccess = function (result, ctx) 
{
	ctx.callBackStatus(result, ctx);
	ctx.showLabel();
}

dnn_control.prototype.DNNLabelEdit.prototype.showLabel = function () 
{
	this.control.innerHTML = this.editWrapper.getText();
	this.control.style.display = '';
	this.control.className = this.css;
	//this.editContainer.style.width = 0; //firefox workaround
	//this.editContainer.style.visibility = 'hidden';	//firefox workaround
	this.editContainer.style.display = 'none';
}

dnn_control.prototype.DNNLabelEdit.prototype.callBackFail = function (result, ctx) 
{
	ctx.cancelEdit();
}

dnn_control.prototype.DNNLabelEdit.prototype.handleKeyPress = function (e) 
{
	if (e == null)
	{
		if (dnn.dom.event != null)	//mini hack
			e = dnn.dom.event.object;
		else
			e = this.editWrapper.container.contentWindow.event;
	}	
	if (e.keyCode == 13 && this.editWrapper.supportsMultiLine == false)
	{
		this.persistEdit();
		return false;
	}	
	else if (e.keyCode == 27)
		this.cancelEdit();		
}

//DNNRichText
dnn_control.prototype.DNNRichText = function (fInit)
{
	this.supportsCE = (document.body.contentEditable != null);
	this.text = '';
	this.supportsMultiLine = true;
	this.document = null;
	this.control = null;
	this.initialized = false;
	this.isRichText = true;

	if (this.supportsCE)
	{
		this.document = document;
		this.container = document.createElement('span');
		this.container.contentEditable = true;	//ie doesn't need no stinkin' iframe
		this.control = this.container;
		this.initialized = true;
	}
	else
	{
		this.container = document.createElement('iframe');
		this.container.src = '';
		this.container.style.border = '0';
		this.initFunc = fInit;	//pointer to function to call when iframe completely loads
		dnn.doDelay(this.container.id + 'initEdit', 10, dnn.dom.getObjMethRef(this, 'initDocument'));	//onreadystate and onload not completely reliable
	}
}

dnn_control.prototype.DNNRichText.prototype.focus = function ()
{
	if (this.supportsCE)
	{
		this.control.focus();
		this.execCommand('selectall');
	}
	else
		this.container.contentWindow.focus();
}

dnn_control.prototype.DNNRichText.prototype.execCommand = function (cmd)
{
	this.document.execCommand(cmd, false, ';');	
}

dnn_control.prototype.DNNRichText.prototype.getText = function ()
{
		return this.control.innerHTML;
}

dnn_control.prototype.DNNRichText.prototype.setText = function (s)
{
	if (this.initialized)
		this.control.innerHTML = s;		
	else
		this.text = s;
}

//method continually called until iframe is completely loaded
dnn_control.prototype.DNNRichText.prototype.initDocument = function ()
{
	if (this.container.contentDocument != null)
	{
		if (this.document == null)	//iframe loaded, now write some HTML, thus causing it to not be loaded again
		{
			this.container.contentDocument.designMode = 'on';
			this.document = this.container.contentWindow.document;
			this.document.open();
			dnn.dom.addSafeHandler(this.container, 'onload', this, 'initDocument');
			this.document.write('<HEAD>' + __dl_getCSS() + '</HEAD><BODY id="__dnn_body"></BODY>');
			this.document.close();
		}
		else if (this.control == null && this.document.getElementById('__dnn_body') != null)	//iframe loaded, now check if body is loaded
		{
			this.control = this.document.getElementById('__dnn_body');
			this.control.style.margin = 0;			
			this.control.tabIndex = 0;
			this.initialized = true;
			this.setText(this.text);
			this.initFunc();		
		}
	}
	if (this.initialized == false)	//iframe and body not loaded, call ourselves until it is
		dnn.doDelay(this.container.id + 'initEdit', 10, dnn.dom.getObjMethRef(this, 'initDocument'));
}

//DNNInputText
dnn_control.prototype.DNNInputText = function (bMultiLine)
{
	if (bMultiLine)
		this.control = document.createElement('textarea');	
	else
	{
		this.control = document.createElement('input');
		this.control.type = 'text';
	}
	this.container = this.control;
	this.initialized = true;
	this.supportsMultiLine = bMultiLine;
	this.isRichText = false;

}

dnn_control.prototype.DNNInputText.prototype.focus = function ()
{
	this.control.focus();
	this.control.select();
}

dnn_control.prototype.DNNInputText.prototype.getText = function ()
{
	return this.control.value;
}

dnn_control.prototype.DNNInputText.prototype.setText = function (s)
{
	this.control.value = s;
}

function __dl_getCSS()	//probably a better way to handle this...
{
	var arr = dnn.dom.getByTagName('link');
	var s = '';
	for (var i=0; i< arr.length; i++)
	{
		s+= '<LINK href="' + arr[i].href + '" type=text/css rel=stylesheet>';
	}
	return s;
}

function __dl_getAttr(oNode, sAttr, sDef)
{
	var sVal = oNode.getAttribute(sAttr);
	if (sVal == null || sVal == '')
		return sDef;
	else
		return sVal;
}

if (typeof(dnn_controls) != 'undefined')
{
	dnn_controls.prototype = new dnn_control;
	dnn_controls.prototype.constructor = dnn_control;
	
	dnn.controls = new dnn_controls();

}

