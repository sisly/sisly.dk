if (typeof(dnn_control) == 'undefined')
	eval('function dnn_control() {}')

dnn_control.prototype.initMenu = function (oCtl) 
{
	dnn.controls.controls[oCtl.id] = new dnn.controls.DNNMenu(oCtl);
	dnn.controls.controls[oCtl.id].generateMenuHTML();
	return dnn.controls.controls[oCtl.id];
}

//------- Constructor -------//
dnn_control.prototype.DNNMenu = function (o)
{

	this.ns = o.id;               //stores namespace for menu
	this.container = o;                    //stores container

	//--- Data Properties ---//  
	this.DOM = new dnn.xml.createDocument();
	this.DOM.loadXml(dnn.getVar(o.id + '_xml'));

	//--- Appearance Properties ---//
	this.mbcss = __dm_getAttr(o, 'mbcss', '');
	this.mcss = __dm_getAttr(o, 'mcss', '');
	this.css = __dm_getAttr(o, 'css', '');
	this.cssChild = __dm_getAttr(o, 'csschild', '');
	this.cssHover = __dm_getAttr(o, 'csshover', '');
	this.cssSel = __dm_getAttr(o, 'csssel', '');
	this.cssIcon = __dm_getAttr(o, 'cssicon', '');

	this.sysImgPath = __dm_getAttr(o, 'sysimgpath', '');
	this.imageList = __dm_getAttr(o, 'imagelist', '').split(',');
	this.workImg = __dm_getAttr(o, 'workimg', 'dnnanim.gif');
	
	this.rootArrow = __dm_getAttr(o, 'rarrowimg', '');
	this.childArrow = __dm_getAttr(o, 'carrowimg', '');
	
	this.target = __dm_getAttr(o, 'target', '');	
	this.defaultJS = __dm_getAttr(o, 'js', '');	
	
	this.postBack = __dm_getAttr(o, 'postback', '');
	this.callBack = __dm_getAttr(o, 'callback', '');
	this.callBackStatFunc = __dm_getAttr(o, 'callbackSF', '');
	//if (this.callBackStatFunc != null)
	//	this.callBackStatFunc = eval(this.callBackStatFunc);
		
	this.selMenuNode=null;  
	this.rootNode = null;	
	this.orient = new Number(__dm_getAttr(o, 'orient', dnn.controls.orient.horizontal));
	
	this.openMenus = new Array();
	//this.delay = new Array();
	this.moutDelay = __dm_getAttr(o, 'moutdelay', '1000');
	this.minDelay = new Number(__dm_getAttr(o, 'mindelay', 0));

	this.anim = __dm_getAttr(o, 'anim', '');	//expand
	this.inAnimObj = null;
	this.inAnimType = null;
	this.useTables = false;
}

dnn_control.prototype.DNNMenu.prototype.getXml = function () 
{
	return this.DOM.getXml();
}

dnn_control.prototype.DNNMenu.prototype.__expandNode = function (oContext) 
{

	this.expandNode(oContext, true);
}

dnn_control.prototype.DNNMenu.prototype.expandNode = function (oMNode, bForce) 
{
	if (this.inAnimObj != null)
		dnn.dom['cancel' + this.inAnimType + 'Element'](this.inAnimObj);

	dnn.cancelDelay(this.ns + 'min');
		
	var oCtr = dnn.dom.getById(__dm_getControlID(this.ns, oMNode.id, 'pctr'));

	if (oMNode.hasPendingNodes)
	{
		var sXml = oMNode.node.getXml();
		oMNode.menu = this;	//need to give reference back to self
		
		if (this.workImg != null)
		{
			var oIcn = dnn.dom.getById(__dm_getControlID(this.ns, oMNode.id, 'icn'));	
			oIcn.src = this.sysImgPath + this.workImg;
		}
		if (this.callBack.indexOf('[NODEXML]') > -1)
			eval(this.callBack.replace('[NODEXML]', dnn.escapeForEval(sXml)));
		else
			eval(this.callBack.replace('[NODEID]', oMNode.id));
	}
	else
	{
		if (oCtr != null)
		{
			if (this.minDelay != '0' && bForce != true)
			{
				dnn.doDelay(this.ns + 'min', this.minDelay, dnn.dom.getObjMethRef(this, '__expandNode'), oMNode);
			}
			else
			{
				this.positionMenu(oMNode, oCtr);
				if (this.anim == 'expand')
				{
					dnn.dom.expandElement(oCtr, null, dnn.dom.getObjMethRef(this, 'animationComplete'));
					this.inAnimObj = oCtr;
					this.inAnimType = 'Expand';
				}
				else
					oCtr.style.display = '';
				
				dnn.dom.positioning.placeOnTop(oCtr, true, this.sysImgPath + 'spacer.gif');
				this.openMenus[this.openMenus.length] = oMNode;
			}
		}
	}
	return true;
}

dnn_control.prototype.DNNMenu.prototype.animationComplete = function()
{
	this.inAnimObj = null;	
	this.inAnimType = null;
}

dnn_control.prototype.DNNMenu.prototype.hideMenus = function (oMNode) 
{
	for (var i=this.openMenus.length-1; i>=0; i--)
	{
		if (oMNode != null && this.openMenus[i].id == oMNode.id)
			break;
		this.collapseNode(this.openMenus[i]);
		this.openMenus.length = this.openMenus.length-1;
	}
}

dnn_control.prototype.DNNMenu.prototype.collapseNode = function (oMNode) 
{
	var oCtr = dnn.dom.getById(__dm_getControlID(this.ns, oMNode.id, 'pctr'));
	if (oCtr != null)
	{
		if (this.anim == 'expand')
		{
			dnn.dom.collapseElement(oCtr, null, dnn.dom.getObjMethRef(this, 'animationComplete'));
			this.inAnimObj = oCtr;
			this.inAnimType = 'Collapse';
		}
		else
			oCtr.style.display = 'none';
	
		dnn.dom.positioning.placeOnTop(oCtr, false);
		//oCtr.style.display = 'none';
		oMNode.expanded = null;
		oMNode.update();
		this.update();
		return true;
	}
}

dnn_control.prototype.DNNMenu.prototype.positionMenu = function (oMNode, oMenu)
{
	var oMItem = dnn.dom.getById(__dm_getControlID(this.ns, oMNode.id, 'ctr'));
	var oPDims = new dnn.dom.positioning.dims(oMItem);
	
	if (this.orient == dnn.controls.orient.vertical || oMNode.level > 0)
	{
		oMenu.style.top = oPDims.t;
		var oMDims = new dnn.dom.positioning.dims(oMenu);

		if (oMDims.t - dnn.dom.positioning.bodyScrollTop() + oMDims.h >= dnn.dom.positioning.viewPortHeight())
		{
			if (oMDims.h < dnn.dom.positioning.viewPortHeight())
				oMenu.style.top = dnn.dom.positioning.viewPortHeight() - oMDims.h + dnn.dom.positioning.bodyScrollTop();	
			//else
			//	spm_handleScrollMenu(me, oMenu);
		}
		
		var oOrigMDims;
		
		if (dnn.dom.browser.isType(dnn.dom.browser.InternetExplorer) == false) //since mozilla doesn't set width greater than window size we need to store it here
			oOrigMDims = new dnn.dom.positioning.dims(oMenu);
		
		oMenu.style.left = oPDims.l + oPDims.w - dnn.dom.positioning.bodyScrollLeft();
		oMDims = new dnn.dom.positioning.dims(oMenu);
		if (oOrigMDims == null)
			oOrigMDims = oMDims;
		
		if (oMDims.l - dnn.dom.positioning.bodyScrollLeft() + oOrigMDims.w > dnn.dom.positioning.viewPortWidth())
		{
			if (dnn.dom.positioning.viewPortWidth() - oOrigMDims.w > 0)  //only do this if it fits
				oMenu.style.left = oPDims.l - oOrigMDims.w - dnn.dom.positioning.bodyScrollLeft();
		}
		

		//oMenu.style.display = "";
	}
	else
	{
		/*
		if (oMenu.direction == 'rtl')			
		{
			var oMDims2 = new dnn.dom.positioning.dims(oMenu);
			oMenu.style.left = (oPDims.l + oPDims.w) - oMDims2.w - dnn.dom.positioning.bodyScrollLeft();
		}
		else			*/
			oMenu.style.left = oPDims.l - dnn.dom.positioning.bodyScrollLeft();
			
		oMenu.style.top = oPDims.t + oPDims.h;
		var oMDims = new dnn.dom.positioning.dims(oMenu);
		
		if (oMDims.l - dnn.dom.positioning.bodyScrollLeft() + oMDims.w > dnn.dom.positioning.viewPortWidth())
		{
			if (dnn.dom.positioning.viewPortWidth() - oMDims.w > 0)  //only do this if it fits
				oMenu.style.left = dnn.dom.positioning.viewPortWidth() - oMDims.w + dnn.dom.positioning.bodyScrollLeft();
		}
		
		if (oMDims.t - dnn.dom.positioning.bodyScrollTop() + oMDims.h > dnn.dom.positioning.viewPortHeight())
		{
			if (oPDims.t - oMDims.h - dnn.dom.positioning.bodyScrollTop() > 0) //only do this if it fits
				oMenu.style.top = oPDims.t - oMDims.h;	//place above menu bar
			//else
			//	spm_handleScrollMenu(me, oMenu);
		}
		//oMenu.style.display = "none";
	}
	
}


dnn_control.prototype.DNNMenu.prototype.selectNode = function (oMNode) 
{
	//var oText = dnn.dom.getById(__dm_getControlID(this.ns, oMNode.id, 't'));
		
	if (this.selMenuNode != null)
	{
		//dnn.dom.getById(__dm_getControlID(this.ns, this.selMenuNode.id, 't')).className = this.nodeCss;
		this.selMenuNode.selected = null;
		this.assignCss(this.selMenuNode);
		this.selMenuNode.update('selected');
	}		
	
	if (oMNode.selected)
	{
		oMNode.selected = null;
		this.assignCss(oMNode);
	}
	else
	{
		oMNode.selected = true;
		this.assignCss(oMNode);
		//dnn.setVar(this.ns + ':selected', oMNode.id);		//BACKWARDS COMPAT ONLY!!!
	}
	oMNode.update('selected');
	
	this.selMenuNode = oMNode;
	this.update();

	if (oMNode.hasNodes || oMNode.hasPendingNodes)
	{
		dnn.cancelDelay(this.ns + 'min');
		this.expandNode(oMNode, true);
	}

	if (oMNode.selected)
	{
		var sJS = '';
		if (this.defaultJS.length > 0)
			sJS = this.defaultJS;
		if (oMNode.js.length > 0)
			sJS = oMNode.js;
		
		if (sJS.length > 0)
		{
			if (eval(sJS) == false)
				return;	//don't do postback if returns false
		}
		
		if (oMNode.clickAction == null || oMNode.clickAction == dnn.controls.action.postback)
			eval(this.postBack.replace('[NODEID]', oMNode.id));
		else if (oMNode.clickAction == dnn.controls.action.nav)
			dnn.dom.navigate(oMNode.url, oMNode.target.length > 0 ? oMNode.target : this.target);
		/*else if (oMNode.clickAction == dnn.controls.action.expand)
		{
			if (oMNode.hasNodes || oMNode.hasPendingNodes)
			{
				if (oMNode.expanded)
					this.collapseNode(oMNode);
				else
					this.expandNode(oMNode);
			}
		}*/
	}
	return true;		
}

dnn_control.prototype.DNNMenu.prototype.assignCss = function (oMNode, oCtr)
{
	if (oCtr == null)
		oCtr = dnn.dom.getById(__dm_getControlID(this.ns, oMNode.id, 'ctr'));//, this.container);
		
	var sNodeCss = this.css;

	if (oMNode.level > 0 && this.cssChild.length > 0)
		sNodeCss = this.cssChild;

	if (oMNode.css.length > 0)
		sNodeCss = oMNode.css;

	//oMNode.hoverCss;

	if (oMNode.hover)
		sNodeCss += ' ' + (oMNode.cssHover.length > 0 ? oMNode.cssHover : this.cssHover);
	if (oMNode.selected)
		sNodeCss += ' ' + (oMNode.cssSel.length > 0 ? oMNode.cssSel : this.cssSel);
	
	oCtr.className = sNodeCss;
}

dnn_control.prototype.DNNMenu.prototype.update = function () 
{
	dnn.setVar(this.ns + '_xml', this.DOM.getXml());
	return true;
}
/*
dnn_control.prototype.DNNMenu.prototype.cancelDelay = function (sType) 
{
	if (this.delay[sType] != null)
	{
		window.clearTimeout(this.delay[sType]);
		this.delay[sType] = null;
	}
}

dnn_control.prototype.DNNMenu.prototype.doDelay = function (sType, iTime, pFunc) 
{
	if (this.delay[sType] == null)
		this.delay[sType] = window.setTimeout(pFunc, iTime);	
}
*/

//--- Event Handlers ---//
dnn_control.prototype.DNNMenu.prototype.callBackStatus = function (result, ctx) 
{
	var oMNode = ctx;
	var oMenu = oMNode.menu;
	
	if (oMenu.callBackStatFunc != null && oMenu.callBackStatFunc.length > 0)
	{
		var oPointerFunc = eval(oMenu.callBackStatFunc);
		oPointerFunc(result, ctx);	
	}
}

dnn_control.prototype.DNNMenu.prototype.callBackSuccess = function (result, ctx) 
{
	var oMNode = ctx;
	var oMenu = oMNode.menu;
	var oParent = oMNode.node;//.parentNode();
	//oParent.removeChild(oMNode.node);
	
	oMNode.node.appendXml(result);
	//oMNode.node = oParent.childNodes(0);

	if (oMenu.workImg != null)
	{
		var oIcn = dnn.dom.getById(__dm_getControlID(oMenu.ns, oMNode.id, 'icn'));
		if (oMNode.image != '')
			oIcn.src = oMNode.image;
		else
			oIcn.src = oMenu.imageList[oMNode.imageIndex];
	}

	//ctx.menu.generateMenuHTML();	
	//get container
	var oCtr = dnn.dom.getById(__dm_getControlID(oMenu.ns, oMNode.id, 'pctr'));
	oMenu.renderNode(oMNode.node, oCtr, true);
	
	oMenu.update();

	var oCtr = dnn.dom.getById(__dm_getControlID(oMenu.ns, oMNode.id, 'pctr'));
	//dnn.dom.expandElement(oCtr);
	oMNode = new dnn.controls.DNNMenuNode(oMNode.node);
	oMenu.expandNode(oMNode);

	if (oMenu.callBackStatFunc != null && oMenu.callBackStatFunc.length > 0)
	{
		var oPointerFunc = eval(oMenu.callBackStatFunc);
		oPointerFunc(result, ctx);	
	}
}

dnn_control.prototype.DNNMenu.prototype.callBackFail = function (result, ctx) 
{
	alert(result);
}


dnn_control.prototype.DNNMenu.prototype.nodeTextClick = function(evt, element)
{
	var oNode = this.DOM.findNode('n', 'id', element.nodeid);
	if (oNode != null)
		this.selectNode(new dnn.controls.DNNMenuNode(oNode));
}

dnn_control.prototype.DNNMenu.prototype.menuMOver = function(evt, element)
{
	dnn.cancelDelay(this.ns + 'mout');
}

dnn_control.prototype.DNNMenu.prototype.menuMOut = function(evt, element)
{
	if (this.moutDelay > 0)
		dnn.doDelay(this.ns + 'mout', this.moutDelay, dnn.dom.getObjMethRef(this, 'hideMenus'));
	else
		this.hideMenus();
}

dnn_control.prototype.DNNMenu.prototype.nodeMOver = function(evt, element)
{
	var oNode = this.DOM.findNode('n', 'id', element.nodeid);
	if (oNode != null)
	{
		var oMNode = new dnn.controls.DNNMenuNode(oNode);
		this.hideMenus(new dnn.controls.DNNMenuNode(oNode.parentNode()));
		oMNode.hover = true;
		this.assignCss(oMNode);
		this.expandNode(oMNode);
	}
}

dnn_control.prototype.DNNMenu.prototype.nodeMOut = function(evt, element)
{
	var oNode = this.DOM.findNode('n', 'id', element.nodeid);
	if (oNode != null)
	{
		var oMNode = new dnn.controls.DNNMenuNode(oNode);
		this.assignCss(oMNode);
	}
}

//--- Generates menu HTML through passed in XML DOM ---//
dnn_control.prototype.DNNMenu.prototype.generateMenuHTML = function () 
{
	for (var i=0; i<this.DOM.childNodeCount(); i++)
	{
		if (this.DOM.childNodes(i).nodeType != 7)
		{
			this.rootNode = this.DOM.childNodes(i);
			break;
		}
	}
	this.container.className = this.mbcss;
	
	this.renderNode(null, this.container);

}

dnn_control.prototype.DNNMenu.prototype.renderNode = function (oNode, oCont, bExists) 
{
	var oChildCont = oCont;
	var oMNode;
	
	if (bExists != true)
	{
		if (oNode != null)
		{
			//render node
			oMNode = new dnn.controls.DNNMenuNode(oNode);
			var oNewContainer;
			var oTR;
			if (oCont.tagName == 'TABLE')
			{
				var oTB;
				var oTBs = dnn.dom.getByTagName('TBODY', oCont);
				if (oTBs.length)
					oTB = oTBs[0];
				if (oTB == null)
				{
					oTB = dnn.dom.createElement('TBODY');
					oCont.appendChild(oTB);
				}
				oTR = dnn.dom.createElement('TR');
				oTB.appendChild(oTR);
				oNewContainer = oTR;
			}
			else
			{
				if (this.orient == dnn.controls.orient.vertical || oMNode.level > 0)	//not sure if I should always use SPAN and for vertical place a BR
					oNewContainer = dnn.dom.createElement('DIV');	//container for Node
				else
					oNewContainer = dnn.dom.createElement('SPAN');	//container for Node
				oCont.appendChild(oNewContainer);
			}				
							
			__dm_assignControlID(oNewContainer, this.ns, oMNode.id, 'ctr');
			dnn.dom.addSafeHandler(oNewContainer, 'onmouseover', this, 'nodeMOver');
			dnn.dom.addSafeHandler(oNewContainer, 'onmouseout', this, 'nodeMOut');
			
			if (oCont.tagName == 'TABLE')
			{
				oNewContainer = dnn.dom.createElement('TD');
				oTR.appendChild(oNewContainer);
			}
				
			if (oMNode.lhtml.length > 0)
				oNewContainer.appendChild(this.renderCustomHTML(oMNode.lhtml));

			if (oMNode.imageIndex > -1 || oMNode.image != '')	//if node has image 
			{
				var oIconCont = this.renderIconCont(oMNode);
				oNewContainer.appendChild(oIconCont);
				
				oIconCont.appendChild(this.renderIcon(oMNode));
			}
			
			if (oCont.tagName == 'TABLE')
			{
				oNewContainer = dnn.dom.createElement('TD');
				oTR.appendChild(oNewContainer);
			}

			oNewContainer.appendChild(this.renderText(oMNode));	//render text
			if (oMNode.toolTip.length > 0)
				oNewContainer.title = oMNode.toolTip;
				
			if (oCont.tagName == 'TABLE')
			{
				oNewContainer = dnn.dom.createElement('TD');
				oTR.appendChild(oNewContainer);
			}

			this.renderArrow(oMNode, oNewContainer);

			if (oMNode.rhtml.length > 0)
				oNewContainer.appendChild(this.renderCustomHTML(oMNode.rhtml));
			
			//oCont.appendChild(oNewContainer);
			
			if (oCont.tagName == 'TABLE')
				this.assignCss(oMNode, oTR);
			else
				this.assignCss(oMNode, oNewContainer);
		
			dnn.dom.addSafeHandler(oCont, 'onmouseover', this, 'menuMOver');
			dnn.dom.addSafeHandler(oCont, 'onmouseout', this, 'menuMOut');
		
		}
		else
			oNode = this.rootNode;

		if (oMNode != null && (oMNode.hasNodes || oMNode.hasPendingNodes))	//if node has children render container and hide if necessary
		{
			if (this.useTables)
			{
				oChildCont = dnn.dom.createElement('TABLE');	//Not using SPAN due to FireFox bug...
				oChildCont.border = 0;
				oChildCont.cellPadding = 0;
				oChildCont.cellSpacing = 0;
			}
			else
				oChildCont = dnn.dom.createElement('DIV');	//Not using SPAN due to FireFox bug...
				
			__dm_assignControlID(oChildCont, this.ns, oMNode.id, 'pctr');
			
			oChildCont.style.position = 'absolute';
			oChildCont.className = this.mcss;
			oChildCont.style.display = 'none';
			this.container.appendChild(oChildCont);			
		}				
	}
		
	for (var i=0; i<oNode.childNodeCount(); i++)	//recursively call child rendering
		this.renderNode(oNode.childNodes(i), oChildCont);
}

dnn_control.prototype.DNNMenu.prototype.renderCustomHTML = function (sHTML) 
{
	var oCtr = dnn.dom.createElement('SPAN');
	oCtr.innerHTML = sHTML;
	return oCtr;	
}


dnn_control.prototype.DNNMenu.prototype.renderIconCont = function (oMNode) 
{
	var oCtr = dnn.dom.createElement('SPAN');
	__dm_assignControlID(oCtr, this.ns, oMNode.id, 'icnc');	
	if (oMNode.cssIcon.length > 0)
		oCtr.className = oMNode.cssIcon;
	else if (this.cssIcon.length > 0)
		oCtr.className = this.cssIcon;
	
	return oCtr;
}

dnn_control.prototype.DNNMenu.prototype.renderIcon = function (oMNode) 
{
	var oImg = dnn.dom.createElement('IMG');
	var oCtr = dnn.dom.createElement('SPAN');
	__dm_assignControlID(oImg, this.ns, oMNode.id, 'icn');	
	if (oMNode.image != '')
		oImg.src = oMNode.image;
	else
		oImg.src = this.imageList[oMNode.imageIndex];
	
	//oImg.style.paddingRight = 10;	//doesn't work in IE???
	oCtr.appendChild(oImg);
	return oCtr;
}

dnn_control.prototype.DNNMenu.prototype.renderArrow = function (oMNode, oCont) 
{
	if (oMNode.hasNodes || oMNode.hasPendingNodes)
	{
		if (oMNode.level == 0 && this.rootArrow.length > 0)
		{
			//oCont.style.backgroundImage = 'url(' + this.rootArrow + ')';
			var oImg = dnn.dom.createElement('IMG');
			oImg.src = this.rootArrow;
			oCont.appendChild(oImg);
		}	
		else if (this.childArrow.length > 0)
			oCont.style.backgroundImage = 'url(' + this.childArrow + ')';

		if (oCont.style.backgroundImage.length > 0)
		{
			oCont.style.backgroundRepeat = 'no-repeat';
			oCont.style.backgroundPosition = 'right';
		}
	}
}

dnn_control.prototype.DNNMenu.prototype.renderSpacer = function (iWidth) 
{
	var oCtr = dnn.dom.createElement('SPAN');
	var oImg = dnn.dom.createElement('IMG');
	oImg.src = this.sysImgPath + 'spacer.gif';
	oImg.width = iWidth;
	oImg.style.width = iWidth;
	oImg.style.height = '1';
	oCtr.appendChild(oImg);
	return oCtr;
}

dnn_control.prototype.DNNMenu.prototype.renderText = function (oMNode) 
{
	var oCtr = dnn.dom.createElement('SPAN');
	__dm_assignControlID(oCtr, this.ns, oMNode.id, 't');		
	oCtr.innerHTML = oMNode.text;	
	oCtr.style.cursor = 'pointer';
	if (oMNode.enabled)
	{
		//oSpan.onclick = dnn.dom.getObjMethRef(this, 'nodeTextClick');
		dnn.dom.addSafeHandler(oCtr, 'onclick', this, 'nodeTextClick');
		//oSpan.onmouseover = dnn.dom.getObjMethRef(this, 'nodeTextMOver');
		//oSpan.onmouseout = dnn.dom.getObjMethRef(this, 'nodeTextMOut');
	}
		
	if (oMNode.selected)
		this.selMenuNode = oMNode;

	return oCtr;
}

dnn_control.prototype.DNNMenuNode = function (oNode)
{
	this.node = oNode; 
	this.level = __dm_getNodeLevel(oNode);

	//base attributes 
	this.id = oNode.getAttribute('id', '');
	this.key = oNode.getAttribute('key', '');
	this.text = oNode.getAttribute('txt', '');
	this.url = oNode.getAttribute('url', '');
	this.js = oNode.getAttribute('js', '');
	this.target = oNode.getAttribute('tar', '');
	this.toolTip = oNode.getAttribute('tTip', '');
	this.enabled = oNode.getAttribute('enabled', '1') != '0';
	this.css = oNode.getAttribute('css', '');
	this.cssSel = oNode.getAttribute('cssSel', '');
	this.cssHover = oNode.getAttribute('cssHover', '');
	this.cssIcon = oNode.getAttribute('cssIcon', '');
	//this.hasNodes = oNode.getAttribute('hasNodes', '0') == '1'; //oNode.childNodeCount() > 0;
	//this.hasPendingNodes = (this.hasNodes && oNode.childNodeCount() == 0) //(oNode.getAttribute('hasNodes', '0') == '1' && this.hasNodes == false);	
	this.hasNodes = oNode.childNodeCount() > 0;
	this.hasPendingNodes = (oNode.getAttribute('hasNodes', '0') == '1' && this.hasNodes == false);	
	//this.populateOnDemand = oNode.getAttribute('pond', '0') == '1';	//IS THIS NECESSARY???
	
	//menu specific attributes
	this.hover = false;
	this.expanded = oNode.getAttribute('expanded', '0') == '1' ? true : null;
	this.selected = oNode.getAttribute('selected', '0') == '1' ? true : null;
	this.clickAction = oNode.getAttribute('ca', dnn.controls.action.postback);
	//this.checkBox = oNode.getAttribute('checkBox', '0');	//IS THIS NECESSARY?
	this.imageIndex = new Number(oNode.getAttribute('imgIdx', '-1'));
	this.image = oNode.getAttribute('img', '');
	this.lhtml = oNode.getAttribute('lhtml', '');
	this.rhtml = oNode.getAttribute('rhtml', '');
}

dnn_control.prototype.DNNMenuNode.prototype.childNodeCount = function ()
{
	return this.node.childNodes.length;
}

dnn_control.prototype.DNNMenuNode.prototype.childNodes = function (iIndex)
{
	if (this.node.childNodes[iIndex] != null)
		return new dnn.controls.DNNMenuNode(this.node.childNodes[iIndex]);
}

dnn_control.prototype.DNNMenuNode.prototype.update = function (sProp)
{
	if (sProp != null)
	{
		var sType = typeof(this[sProp]);
		
		if (sType == 'string' || sType == 'number' || this[sProp] == null)
			this.node.setAttribute(sProp, this[sProp]);
		else if (sType == 'boolean')
			this.node.setAttribute(sProp, new Number(this[sProp]));
	}
	else
	{
		for (sProp in this)
			this.update(sProp);
	
	
	//var oXNode = new dnn.xml.XmlNode(this.node);
	//alert(oXNode.getXml());
	//alert(oXNode.getDocumentXml());
	
	}
}

function __dm_getAttr(oNode, sAttr, sDef)
{
	var sVal = oNode.getAttribute(sAttr);
	if (sVal == null || sVal == '')
		return sDef;
	else
		return sVal;
}

function __dm_getNodeLevel(oNode)
{
	var i=0;
	while (oNode != null)
	{
		oNode = oNode.parentNode();
		if (oNode == null || oNode.nodeName() == 'root')	//hardcode???
			break;
		i++;
	
	}	
	return i;
}

function __dm_assignControlID(oCtl, sNS, sID, sPrefix)
{
	oCtl.ns = sNS;
	oCtl.nodeid = sID;
	//oCtl.id = oCtl.ns + '_' + oCtl.nodeid + '_' + sPrefix;
	oCtl.id = __dm_getControlID(oCtl.ns, oCtl.nodeid, sPrefix);
}

function __dm_getControlID(sNS, sID, sPrefix)
{
	//return sPrefix + sID;	//sNS + '_' +	
	if (dnn.controls.length == 1)
		return sPrefix + sID;	//inclusion of ns causes issue with old __dm_DNNMenuNode code, so if only one menun then don't use as workaround
	else
		return sNS + sPrefix + sID;	
}

if (typeof(dnn_controls) != 'undefined')
{
	dnn_controls.prototype = new dnn_control;
	dnn_controls.prototype.constructor = dnn_control;
	
	dnn.controls = new dnn_controls();

}
